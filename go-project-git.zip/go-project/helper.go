package main

import (
	"fmt"
	"strings"
	"time"
) 
func validateUserInput(firstName string, lastName string, emailAddress string, userTickets uint,) (bool,bool,bool){
	isValidName := len(firstName) >= 2 && len(lastName) >= 2
	isValidEmail := strings.Contains(emailAddress, "@")
	isValidTicketNumber := userTickets > 0 && userTickets <= remainingTickets
	return isValidName, isValidEmail, isValidTicketNumber
}

func sentTicket(userTickets uint, firstName string, lastName string, emailAddress string)  {
	time.Sleep(10 *time.Second)
	var ticket = fmt.Sprintf("%v tickets for %v %v", userTickets, firstName, lastName)
	fmt.Println("##############")
	fmt.Printf("Sending ticket: \n %v \nto email address %v\n", ticket, emailAddress)
	fmt.Println("##############")
	wg.Done()

}